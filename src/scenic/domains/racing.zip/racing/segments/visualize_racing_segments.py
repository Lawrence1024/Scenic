#!/usr/bin/env python3
"""
Visualize curve/straight segments derived from the OpenDRIVE map.

Segments are deterministic for the same map: same centerline geometry and
CURVATURE_THRESHOLD yield the same segment boundaries every run. This script
loads the same track as the racing scenario, builds the segments, and shows
them in a window.

Usage (from repo root):
    python -m scenic.domains.racing.segments.visualize_racing_segments [--map PATH]

Example:
    python -m scenic.domains.racing.segments.visualize_racing_segments --map assets/maps/dSPACE/LagunaSeca.xodr
"""

import argparse
import sys
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import matplotlib.patheffects as path_effects

from scenic.domains.racing.tracks import createRacingTrack
from scenic.domains.racing.segments.segment_map import (
    _get_road_centerline,
    _build_curve_straight_segments,
    CURVATURE_THRESHOLD,
)


def _find_repo_root() -> Path:
    """Find repo root (directory containing 'src' and 'assets')."""
    p = Path(__file__).resolve().parent
    for _ in range(10):
        if (p / "src").is_dir() and (p / "assets").is_dir():
            return p
        p = p.parent
    return Path(__file__).resolve().parent.parent.parent.parent.parent.parent


def _dist2(p, q):
    dx = float(q[0]) - float(p[0])
    dy = float(q[1]) - float(p[1])
    return (dx * dx + dy * dy) ** 0.5


def get_segment_polyline(centerline, s_start: float, s_end: float):
    """Return list of (x, y) for centerline points with s in [s_start, s_end]."""
    ls = getattr(centerline, "lineString", None)
    if ls is None:
        return []
    coords = list(getattr(ls, "coords", []))
    if len(coords) < 2:
        return []
    n = len(coords)
    s_cum = [0.0]
    for i in range(1, n):
        s_cum.append(s_cum[-1] + _dist2(coords[i - 1], coords[i]))
    points = []
    for j in range(n):
        if s_start <= s_cum[j] <= s_end:
            points.append((float(coords[j][0]), float(coords[j][1])))
    return points


def main():
    parser = argparse.ArgumentParser(description="Visualize racing track curve/straight segments")
    parser.add_argument(
        "--map",
        default=None,
        help="Path to OpenDRIVE .xodr (default: assets/maps/dSPACE/LagunaSeca.xodr)",
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=CURVATURE_THRESHOLD,
        help=f"Curvature threshold 1/m (default: {CURVATURE_THRESHOLD})",
    )
    parser.add_argument(
        "--output",
        "-o",
        default=None,
        help="Save figure to path (e.g. segment_visualization.png) instead of only showing",
    )
    parser.add_argument(
        "--no-pit",
        action="store_true",
        help="Do not include pit roads in segment list or visualization",
    )
    parser.add_argument(
        "--main-loop-ids",
        nargs="*",
        type=int,
        default=None,
        help="OpenDRIVE road IDs of junction links for outer loop (e.g. 24 34). If omitted, chosen by smoothness.",
    )
    parser.add_argument(
        "--pit-ids",
        nargs="*",
        type=int,
        default=None,
        help="OpenDRIVE road IDs of junction links to pit (e.g. 25 30). If omitted, auto-detected by topology.",
    )
    args = parser.parse_args()

    repo_root = _find_repo_root()
    map_path = args.map
    if map_path is None:
        map_path = repo_root / "assets" / "maps" / "dSPACE" / "LagunaSeca.xodr"
    else:
        map_path = Path(map_path)
    if not map_path.is_absolute():
        map_path = repo_root / map_path
    if not map_path.exists():
        print(f"Map not found: {map_path}")
        sys.exit(1)

    print(f"Loading track from {map_path} ...")
    main_loop_ids = tuple(args.main_loop_ids) if args.main_loop_ids else None
    pit_ids = tuple(args.pit_ids) if args.pit_ids else None
    track = createRacingTrack(
        str(map_path),
        direction="counterclockwise",
        pitLaneRoadName="pit",
        main_loop_connecting_road_ids=main_loop_ids,
        pit_connecting_road_ids=pit_ids,
    )
    main_roads = getattr(track, "_mainRacingRoads", None) or []
    pit_roads = (getattr(track, "_pitRoads", None) or []) if not args.no_pit else []
    roads = main_roads + pit_roads
    if not roads:
        print("No main racing roads found.")
        sys.exit(1)

    conn_set = set(getattr(track.network, "connectingRoads", ()))
    n_main_roads = len(main_roads)
    junction_main_road_ids = [getattr(r, "id", None) for r in main_roads if r in conn_set]
    junction_pit_road_ids = [getattr(r, "id", None) for r in pit_roads if r in conn_set]
    print(f"Junction assignment: main_loop={'explicit IDs ' + str(main_loop_ids) if main_loop_ids else 'smoothness'}, pit={'explicit IDs ' + str(pit_ids) if pit_ids else 'topology'}")
    if junction_main_road_ids:
        print(f"  Main-loop junction links (road IDs): {junction_main_road_ids}")
    if junction_pit_road_ids:
        print(f"  Pit junction links (road IDs): {junction_pit_road_ids}")

    # Build segments per road (main first, then pit) — final segmenting used by behaviors/MPC
    all_segments = []  # (segment_id, road_idx, s_start, s_end, seg_type, centerline, is_junction_link, is_pit)
    seg_id = 1
    for road_idx, road in enumerate(roads):
        centerline = _get_road_centerline(road)
        if centerline is None:
            continue
        is_pit = road_idx >= n_main_roads
        is_junction_link = road in conn_set

        if is_junction_link:
            L = centerline.length
            segs = [(0.0, L, "junction")]
        else:
            segs = _build_curve_straight_segments(centerline, curvature_threshold=args.threshold)

        for s_start, s_end, seg_type in segs:
            all_segments.append((seg_id, road_idx, s_start, s_end, seg_type, centerline, is_junction_link, is_pit))
            seg_id += 1

    total = len(all_segments)
    n_main_seg = sum(1 for s in all_segments if not s[7])  # not is_pit
    n_pit_seg = total - n_main_seg
    print(f"\nFinal segmenting: {total} segments (threshold={args.threshold})")
    print(f"  Main loop: segments 1–{n_main_seg}  ({n_main_roads} roads, junction links included)")
    if n_pit_seg:
        print(f"  Pit lane:  segments {n_main_seg + 1}–{total}  ({len(pit_roads)} roads, junction links included)")
    print("Segment lengths (m): id  type      length  main/pit  junction?")
    for seg in all_segments:
        seg_id, road_idx, s_start, s_end, seg_type, _, is_junc, is_pit = seg
        length = s_end - s_start
        part = "pit " if is_pit else "main"
        j = "yes" if is_junc else ""
        print(f"  {seg_id:2d}   {seg_type:8s}  {length:7.1f}  {part:4s}    {j}")

    # Non-junction: straight=blue, curve=orange. Junction (the 4 pieces): one distinct color so they are unambiguous.
    COLOR_STRAIGHT = "tab:blue"
    COLOR_CURVE = "tab:orange"
    COLOR_JUNCTION = "forestgreen"
    fig, ax = plt.subplots(1, 1, figsize=(12, 10))

    non_junction = [s for s in all_segments if not s[6]]
    junction_only = [s for s in all_segments if s[6]]
    for seg in non_junction + junction_only:
        seg_id, road_idx, s_start, s_end, seg_type, centerline, is_junction_link, is_pit = seg
        pts = get_segment_polyline(centerline, s_start, s_end)
        if len(pts) < 2:
            continue
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        if is_junction_link:
            color = COLOR_JUNCTION
            lw = 4.0
        else:
            color = COLOR_STRAIGHT if seg_type == "straight" else COLOR_CURVE
            lw = 2.5
        ax.plot(xs, ys, color=color, linewidth=lw, solid_capstyle="round", linestyle="-")
        mid_idx = len(pts) // 2
        x_mid, y_mid = pts[mid_idx][0], pts[mid_idx][1]
        ax.text(
            x_mid, y_mid, str(seg_id),
            fontsize=8, ha="center", va="center", color="white", fontweight="bold",
            path_effects=[path_effects.withStroke(linewidth=2, foreground="black")],
        )

    ax.set_aspect("equal")
    ax.set_xlabel("x (m)")
    ax.set_ylabel("y (m)")
    n_junc = len(junction_only)
    junc_ids = sorted(s[0] for s in junction_only)
    title = f"Final segmenting (n={total}) — 1–{n_main_seg} main, {n_main_seg + 1}–{total} pit. Green = junction segments {junc_ids}."
    ax.set_title(title)
    legend_handles = [
        Line2D([0], [0], color=COLOR_STRAIGHT, linewidth=2, label="Straight"),
        Line2D([0], [0], color=COLOR_CURVE, linewidth=2, label="Curve"),
        Patch(facecolor="none", edgecolor="none", label=f"Main loop: segments 1–{n_main_seg}"),
    ]
    if n_pit_seg:
        legend_handles.append(Patch(facecolor="none", edgecolor="none", label=f"Pit: segments {n_main_seg + 1}–{total}"))
    if n_junc:
        legend_handles.append(Line2D([0], [0], color=COLOR_JUNCTION, linewidth=4, linestyle="-", label=f"Junction ({n_junc}): {junc_ids}"))
    ax.legend(handles=legend_handles, loc="upper left")
    plt.tight_layout()
    if args.output:
        out_path = Path(args.output)
        if not out_path.is_absolute():
            out_path = repo_root / out_path
        out_path.parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(out_path, dpi=150)
        print(f"Saved: {out_path}")
    plt.show()


if __name__ == "__main__":
    main()
