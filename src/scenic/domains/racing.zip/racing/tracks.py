"""Racing track representation extending the driving domain's road network.

This module extends the road network classes from :obj:`scenic.domains.driving.roads`
with racing-specific concepts like pit lanes, sectors, racing lines, and track direction.
"""

from __future__ import annotations

import math
from typing import List, Optional, Tuple, Union
import attr

from scenic.domains.driving.roads import (
    Network, Road, Lane, LaneSection,
    Intersection,
    ManeuverType, NetworkElement
)
from scenic.core.regions import PolygonalRegion, PolylineRegion
from scenic.core.vectors import Vector, OrientedVector
from scenic.core.distributions import RejectionException


def _road_centerline(road: Road):
    """First lane centerline of a road, or None."""
    if not getattr(road, "lanes", None) or len(road.lanes) == 0:
        return None
    return getattr(road.lanes[0], "centerline", None)


def _road_endpoint_and_heading(road: Road, at_start: bool) -> Optional[Tuple[float, float, float]]:
    """Return (x, y, heading_rad) at the start or end of the road's centerline. None if not available."""
    cl = _road_centerline(road)
    if cl is None or len(cl) < 2:
        return None
    if at_start:
        p0, p1 = cl[0], cl[1]
    else:
        p0, p1 = cl[-2], cl[-1]
    dx = float(p1.x - p0.x)
    dy = float(p1.y - p0.y)
    heading = math.atan2(dy, dx)
    pt = cl[0] if at_start else cl[-1]
    return (float(pt.x), float(pt.y), heading)


def _angle_diff(a_rad: float, b_rad: float) -> float:
    """Smallest angle difference in [-pi, pi] (absolute value)."""
    d = a_rad - b_rad
    while d > math.pi:
        d -= 2 * math.pi
    while d < -math.pi:
        d += 2 * math.pi
    return abs(d)


def _smoothness_conn_to_mains(
    conn_road: Road,
    main_roads: List[Road],
) -> Optional[float]:
    """
    Smoothness score for a connecting road that links two main roads: sum of angle differences
    at the two connection points. Lower = smoother. Returns None if geometry is missing.
    """
    cl = _road_centerline(conn_road)
    if cl is None or len(cl) < 2:
        return None
    conn_start_pt = (float(cl[0].x), float(cl[0].y))
    conn_end_pt = (float(cl[-1].x), float(cl[-1].y))
    conn_start_heading = math.atan2(float(cl[1].y - cl[0].y), float(cl[1].x - cl[0].x))
    conn_end_heading = math.atan2(float(cl[-1].y - cl[-2].y), float(cl[-1].x - cl[-2].x))

    def dist_pt(a, b):
        return (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2

    best = None
    for ma in main_roads:
        for mb in main_roads:
            if ma is mb:
                continue
            ha_start = _road_endpoint_and_heading(ma, at_start=True)
            ha_end = _road_endpoint_and_heading(ma, at_start=False)
            hb_start = _road_endpoint_and_heading(mb, at_start=True)
            hb_end = _road_endpoint_and_heading(mb, at_start=False)
            if ha_start is None or ha_end is None or hb_start is None or hb_end is None:
                continue
            d_cs_ma_end = dist_pt(conn_start_pt, (ha_end[0], ha_end[1]))
            d_cs_ma_start = dist_pt(conn_start_pt, (ha_start[0], ha_start[1]))
            d_ce_mb_end = dist_pt(conn_end_pt, (hb_end[0], hb_end[1]))
            d_ce_mb_start = dist_pt(conn_end_pt, (hb_start[0], hb_start[1]))
            # Conn start meets one main's endpoint; conn end meets the other main's endpoint
            if d_cs_ma_end <= d_cs_ma_start and d_ce_mb_start <= d_ce_mb_end:
                score = _angle_diff(ha_end[2], conn_start_heading) + _angle_diff(conn_end_heading, hb_start[2])
            elif d_cs_ma_start <= d_cs_ma_end and d_ce_mb_end <= d_ce_mb_start:
                score = _angle_diff(ha_start[2], conn_start_heading) + _angle_diff(conn_end_heading, hb_end[2])
            elif d_cs_ma_end <= d_cs_ma_start and d_ce_mb_end <= d_ce_mb_start:
                score = _angle_diff(ha_end[2], conn_start_heading) + _angle_diff(conn_end_heading, hb_end[2])
            elif d_cs_ma_start <= d_cs_ma_end and d_ce_mb_start <= d_ce_mb_end:
                score = _angle_diff(ha_start[2], conn_start_heading) + _angle_diff(conn_end_heading, hb_start[2])
            else:
                continue
            if best is None or score < best:
                best = score
    return best


@attr.s(auto_attribs=True, kw_only=True, eq=False)
class Sector:
    """A sector of a racing track for timing purposes.
    
    Racing tracks are typically divided into 2-3 sectors to measure
    lap times and performance through different parts of the circuit.
    
    Attributes:
        number: Sector number (1, 2, 3, etc.)
        startDistance: Distance along track where sector starts (in meters)
        endDistance: Distance along track where sector ends (in meters)
        region: The geographic region covered by this sector
        name: Optional name for the sector (e.g., "Corkscrew", "Hairpin")
    """
    number: int
    startDistance: float
    endDistance: float
    region: PolygonalRegion
    name: Optional[str] = None
    
    @property
    def length(self) -> float:
        """Length of the sector in meters."""
        return self.endDistance - self.startDistance


@attr.s(auto_attribs=True, kw_only=True, eq=False)
class PitLane:
    """A pit lane on a racing track.
    
    Pit lanes are special lanes where cars can stop for service (tire changes,
    refueling, repairs). They typically have:
    - Speed limits (enforced)
    - Entry and exit points
    - Pit boxes for each team
    - Separate from main racing lanes
    
    Attributes:
        lane: The underlying Lane object representing the pit lane
        speedLimit: Speed limit in m/s (typically 60-80 km/h = 16-22 m/s)
        entryPoint: Point where cars can enter the pit lane
        exitPoint: Point where cars rejoin the racing line
        pitBoxes: List of regions representing individual pit boxes
    """
    lane: Lane
    speedLimit: float = 22.0  # ~80 km/h default
    entryPoint: Optional[Vector] = None
    exitPoint: Optional[Vector] = None
    pitBoxes: List[PolygonalRegion] = attr.Factory(list)
    
    @property
    def region(self) -> PolygonalRegion:
        """The region covered by the pit lane."""
        return self.lane.polygon
    
    @property
    def centerline(self) -> PolylineRegion:
        """The centerline of the pit lane."""
        return self.lane.centerline
    
    def isPitBox(self, position: Vector) -> bool:
        """Check if a position is in any pit box."""
        for box in self.pitBoxes:
            if position in box:
                return True
        return False


@attr.s(auto_attribs=True, kw_only=True, eq=False)
class RacingLine:
    """The optimal racing line through a section of track.
    
    The racing line is the fastest path through a corner or section of track,
    typically using the full width of the track to maximize corner speed.
    
    Attributes:
        path: The polyline representing the racing line
        section: The section of track this racing line covers
        speedProfile: Optional list of (distance, recommended_speed) tuples
    """
    path: PolylineRegion
    section: str = "general"  # e.g., "turn_1", "main_straight", etc.
    speedProfile: List[Tuple[float, float]] = attr.Factory(list)
    
    def recommendedSpeedAt(self, distance: float) -> Optional[float]:
        """Get the recommended speed at a given distance along the racing line."""
        if not self.speedProfile:
            return None
        
        # Find the closest point in the speed profile
        closest_dist = min(self.speedProfile, key=lambda x: abs(x[0] - distance))
        return closest_dist[1]


class RacingTrack:
    """A racing track (closed-loop circuit).
    
    Extends the Network concept from the driving domain with racing-specific features:
    - Enforced track direction (one-way)
    - Pit lane identification
    - Sector divisions
    - Racing line
    - Start/finish line
    - Starting grid positions
    
    Attributes:
        network: The underlying road Network
        direction: 'clockwise' or 'counterclockwise'
        pitLane: The pit lane, if any
        sectors: List of track sectors
        racingLine: The optimal racing line
        startFinishLine: Position of the start/finish line
        trackLength: Total length of the racing circuit in meters
        startingGrid: List of positions for race starts
    """
    
    def __init__(
        self,
        network: Network,
        direction: str = 'clockwise',
        trackLength: Optional[float] = None,
        pitLaneRoadId: Optional[str] = None,
        pitLaneRoadName: Optional[str] = None,
        mainLineRoadId: Optional[str] = None,
        main_loop_connecting_road_ids: Optional[Tuple[Union[int, str], ...]] = None,
        pit_connecting_road_ids: Optional[Tuple[Union[int, str], ...]] = None,
    ):
        """Initialize a racing track from a road network.

        Args:
            network: Road network (typically from OpenDRIVE file)
            direction: 'clockwise' or 'counterclockwise'
            trackLength: Total track length in meters (auto-detected if None)
            pitLaneRoadId: OpenDRIVE road ID for pit lane (optional)
            pitLaneRoadName: Pattern to match pit lane name (e.g., "Pit Lane", "pit")
            mainLineRoadId: OpenDRIVE road ID for main racing line (optional)
            main_loop_connecting_road_ids: OpenDRIVE road IDs of junction connecting roads
                for the outer loop (e.g. (24, 34)). If None, at each junction the link that
                smoothly connects the two main roads (smallest angle change) is used.
            pit_connecting_road_ids: OpenDRIVE road IDs of junction connecting roads to the
                pit (e.g. (25, 30)). If None, pit links are auto-detected (conn that has
                the pit road at the junction).
        """
        self.network = network
        self.direction = direction
        self.trackLength = trackLength or self._calculateTrackLength()

        # User-specified road identifiers
        self.pitLaneRoadId = pitLaneRoadId
        self.pitLaneRoadName = pitLaneRoadName or "pit"  # Default pattern
        self.mainLineRoadId = mainLineRoadId
        self.main_loop_connecting_road_ids = main_loop_connecting_road_ids
        self.pit_connecting_road_ids = pit_connecting_road_ids or ()

        # Racing-specific features (to be populated)
        self.pitLane: Optional[PitLane] = None
        self.sectors: List[Sector] = []
        self.racingLine: Optional[RacingLine] = None
        self.startFinishLine: Optional[Vector] = None
        self.startingGrid: List[Vector] = []

        # Track segments: Two mutually exclusive regions
        # mainRacingRoad = union of all main loop roads (main line + chosen junction links)
        # pitLaneRoad = primary pit road; _pitRoads = all pit roads (primary + junction links)
        self.mainRacingRoad: Optional[Union[Road, Region]] = None
        self.pitLaneRoad: Optional[Road] = None
        self._mainRacingRoads: List[Road] = []
        self._pitRoads: List[Road] = []
        
        # Analyze the network to identify racing features
        self._identifyRacingFeatures()
    
    def _calculateTrackLength(self) -> float:
        """Calculate total track length by following the main racing line."""
        # Find the longest continuous path (main track)
        max_length = 0.0
        for road in self.network.roads:
            road_length = sum(lane.centerline.length for lane in road.lanes)
            max_length = max(max_length, road_length)
        return max_length
    
    def _identifyRacingFeatures(self):
        """Identify pit lanes, sectors, and other racing features from the network."""
        
        print(f"\n[RacingTrack] Identifying track features...")
        print(f"  Total roads in network: {len(self.network.roads)}")
        
        # Step 1: Identify road segments (main line, pit lane, parallel roads)
        self._identifyRoadSegments()
        
        # Step 2: Create pit lane if identified (_pitRoads may include junction links)
        if self.pitLaneRoad is not None:
            if self.pitLaneRoad.lanes:
                self.pitLane = PitLane(lane=self.pitLaneRoad.lanes[0])
                print(f"  [OK] Pit lane identified: {self.pitLaneRoad} ({len(self._pitRoads)} road(s) total)")
        else:
            print(f"  [INFO] No pit lane identified (will use all roads as racing line)")
        
        # Step 3: Auto-generate sectors if not specified
        # Common practice: divide track into 3 equal sectors
        if not self.sectors and self.trackLength > 0:
            sector_length = self.trackLength / 3.0
            for i in range(3):
                self.sectors.append(Sector(
                    number=i + 1,
                    startDistance=i * sector_length,
                    endDistance=(i + 1) * sector_length,
                    region=self.network.drivableRegion,  # Simplified
                    name=f"Sector {i + 1}"
                ))
            print(f"  [OK] Generated {len(self.sectors)} sectors")
    
    def _identifyRoadSegments(self):
        """Identify pit lane and main racing roads from the network.
        
        Creates two mutually exclusive segments:
        - pitLaneRoad: The pit lane
        - mainRacingRoad: Union of all non-pit roads (main line + parallel roads)
        
        Uses multiple strategies:
        1. User-specified road IDs (pitLaneRoadId)
        2. Road name patterns (e.g., "Pit Lane")
        3. Remaining roads become part of mainRacingRoad
        """
        
        print(f"\n  [Track Segments] Analyzing road structure...")
        
        # Analyze each road
        road_info = []
        for road in self.network.roads:
            # Get road properties
            road_id = getattr(road, 'id', None)
            road_name = getattr(road, 'name', str(road))
            
            # Use actual road length (not sum of all lanes)
            if hasattr(road, 'length'):
                road_length = road.length
            elif road.lanes:
                road_length = road.lanes[0].centerline.length
            else:
                road_length = 0
            
            road_info.append({
                'road': road,
                'id': road_id,
                'name': road_name,
                'length': road_length
            })
            
            print(f"    Road: {road_name[:50]}")
            print(f"      ID: {road_id}, Length: {road_length:.1f}m, Lanes: {len(road.lanes)}")
        
        # Sort by length (longest first)
        road_info.sort(key=lambda x: x['length'], reverse=True)
        
        # Step 1: Identify pit lane
        # Strategy 1a: User-specified pit lane ID
        if self.pitLaneRoadId:
            for info in road_info:
                if str(info['id']) == str(self.pitLaneRoadId):
                    self.pitLaneRoad = info['road']
                    print(f"\n  [OK] Pit lane identified by ID: {info['name']} ({info['length']:.1f}m)")
                    break
        
        # Strategy 1b: Name pattern matching for pit lane
        if self.pitLaneRoad is None and self.pitLaneRoadName:
            pattern = self.pitLaneRoadName.lower()
            for info in road_info:
                if pattern in info['name'].lower():
                    self.pitLaneRoad = info['road']
                    print(f"\n  [OK] Pit lane identified by name: {info['name']} ({info['length']:.1f}m)")
                    break
        
        # Step 2: All non-pit roads become mainRacingRoad
        for info in road_info:
            road = info['road']
            if road != self.pitLaneRoad:
                self._mainRacingRoads.append(road)
                print(f"  [INFO] Main racing road: {info['name']} ({info['length']:.1f}m)")

        def _road_length(r):
            if hasattr(r, 'length'):
                return r.length
            if r.lanes:
                return r.lanes[0].centerline.length
            return 0.0

        def _road_id_match(road, id_list):
            if not id_list:
                return False
            rid = getattr(road, 'id', None)
            if rid is None:
                return False
            rid = int(rid) if rid is not None else None
            for i in id_list:
                if rid == (int(i) if i is not None else None):
                    return True
            return False

        connecting_roads = tuple(getattr(self.network, 'connectingRoads', ()))
        main_loop_ids = self.main_loop_connecting_road_ids
        pit_conn_ids = tuple(self.pit_connecting_road_ids) if self.pit_connecting_road_ids else ()
        intersections = tuple(getattr(self.network, 'intersections', ()))
        conn_set = set(connecting_roads)

        def _junction_center(junc):
            """(x, y) of junction polygon centroid, or None."""
            try:
                poly = getattr(junc, "polygon", None)
                if poly is not None:
                    c = poly.centroid
                    return (float(c.x), float(c.y))
            except Exception:
                pass
            return None

        def _conn_center(conn_road: Road):
            """(x, y) of connecting road center (midpoint of centerline), or None."""
            pt_start = _road_endpoint_and_heading(conn_road, at_start=True)
            pt_end = _road_endpoint_and_heading(conn_road, at_start=False)
            if pt_start is not None and pt_end is not None:
                return ((pt_start[0] + pt_end[0]) * 0.5, (pt_start[1] + pt_end[1]) * 0.5)
            return None

        def _conn_at_junction(conn_road: Road, junc) -> bool:
            """True if this connecting road belongs to the given junction (both endpoints at junction)."""
            pred = getattr(conn_road, "_predecessor", None)
            succ = getattr(conn_road, "_successor", None)
            jroads = set(getattr(junc, "roads", ()))
            if not jroads:
                return False
            # Parser may link conn to Intersection or directly to Road
            pred_at = pred == junc or (pred in jroads)
            succ_at = succ == junc or (succ in jroads)
            return pred_at and succ_at

        def _conn_belongs_to_junction(conn_road: Road, junc, all_juncs) -> bool:
            """True if this conn is at this junction and this junction is the closest to the conn (by center distance)."""
            if not _conn_at_junction(conn_road, junc):
                return False
            conn_pt = _conn_center(conn_road)
            junc_pt = _junction_center(junc)
            if conn_pt is None or junc_pt is None:
                return True
            best_dist_sq = (conn_pt[0] - junc_pt[0]) ** 2 + (conn_pt[1] - junc_pt[1]) ** 2
            junc_idx = all_juncs.index(junc) if junc in all_juncs else -1
            for other in all_juncs:
                if other is junc or not _conn_at_junction(conn_road, other):
                    continue
                other_pt = _junction_center(other)
                if other_pt is None:
                    continue
                d_sq = (conn_pt[0] - other_pt[0]) ** 2 + (conn_pt[1] - other_pt[1]) ** 2
                other_idx = all_juncs.index(other)
                if d_sq < best_dist_sq or (d_sq == best_dist_sq and other_idx < junc_idx):
                    return False
            return True

        def _conn_connects_to_road(conn: Road, road: Road) -> bool:
            """True if a connecting road has an endpoint within ~5m of the road's start or end."""
            c_start = _road_endpoint_and_heading(conn, at_start=True)
            c_end = _road_endpoint_and_heading(conn, at_start=False)
            r_start = _road_endpoint_and_heading(road, at_start=True)
            r_end = _road_endpoint_and_heading(road, at_start=False)
            if c_start is None or c_end is None or r_start is None or r_end is None:
                return False
            tol = 5.0 ** 2
            def near(a, b):
                return (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 <= tol
            return (near((c_start[0], c_start[1]), (r_start[0], r_start[1])) or near((c_start[0], c_start[1]), (r_end[0], r_end[1]))
                or near((c_end[0], c_end[1]), (r_start[0], r_start[1])) or near((c_end[0], c_end[1]), (r_end[0], r_end[1])))

        def _pit_conn_at_junction(junc):
            """Return the pit junction link at this junction (from _pitRoads), or None."""
            for c in self._pitRoads:
                if c in conn_set and _conn_belongs_to_junction(c, junc, intersections):
                    return c
            return None

        def _divergence_angle_with_pit(main_conn: Road, pit_conn: Road) -> float:
            """
            Angle (radians) between the main connector and pit connector centerlines at the junction.
            Higher = more natural fork (centerlines diverge). Returns 0 if geometry is missing.
            """
            def dist_sq(a, b):
                return (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2
            ms = _road_endpoint_and_heading(main_conn, at_start=True)
            me = _road_endpoint_and_heading(main_conn, at_start=False)
            ps = _road_endpoint_and_heading(pit_conn, at_start=True)
            pe = _road_endpoint_and_heading(pit_conn, at_start=False)
            if ms is None or me is None or ps is None or pe is None:
                return 0.0
            # Junction is where main and pit meet: closest pair of endpoints; use their headings at that end
            pairs = [
                ((ms[0], ms[1]), ms[2], (ps[0], ps[1]), ps[2]),
                ((ms[0], ms[1]), ms[2], (pe[0], pe[1]), pe[2]),
                ((me[0], me[1]), me[2], (ps[0], ps[1]), ps[2]),
                ((me[0], me[1]), me[2], (pe[0], pe[1]), pe[2]),
            ]
            best = float("inf")
            main_heading, pit_heading = None, None
            for mx, mh, px, ph in pairs:
                d = dist_sq(mx, px)
                if d < best:
                    best = d
                    main_heading = mh
                    pit_heading = ph
            if main_heading is None or pit_heading is None:
                return 0.0
            return _angle_diff(main_heading, pit_heading)

        # Step 2a: Build _pitRoads = primary pit road + junction connecting roads to pit
        self._pitRoads = [self.pitLaneRoad] if self.pitLaneRoad else []
        if pit_conn_ids:
            for conn_road in connecting_roads:
                if _road_id_match(conn_road, pit_conn_ids):
                    self._pitRoads.append(conn_road)
                    conn_name = getattr(conn_road, 'name', str(conn_road))[:50]
                    conn_len = _road_length(conn_road)
                    print(f"  [INFO] Pit (junction link): {conn_name} ({conn_len:.1f}m)")
        else:
            # Auto-detect pit links: at most one connecting road per junction that has the pit and connects to the pit (4 pieces total: 2 main + 2 pit)
            for junc in intersections:
                if self.pitLaneRoad is None or self.pitLaneRoad not in getattr(junc, "roads", ()):
                    continue
                pit_conns_here = [
                    c for c in connecting_roads
                    if c not in self._pitRoads and _conn_belongs_to_junction(c, junc, intersections) and _conn_connects_to_road(c, self.pitLaneRoad)
                ]
                if not pit_conns_here:
                    continue
                # Pick the full pit entry/exit (longest connector), not the shortest stub
                best = max(pit_conns_here, key=_road_length)
                self._pitRoads.append(best)
                conn_name = getattr(best, 'name', str(best))[:50]
                conn_len = _road_length(best)
                print(f"  [INFO] Pit (junction link, auto): {conn_name} ({conn_len:.1f}m)")
        if self._pitRoads and not self.pitLaneRoad:
            self.pitLaneRoad = self._pitRoads[0]

        # Step 2b: Add junction connecting roads to main loop — either explicit IDs or smoothness-based
        n_main = len(self._mainRacingRoads)
        main_racing_set = set(self._mainRacingRoads)

        if main_loop_ids is not None:
            for conn_road in connecting_roads:
                if conn_road in main_racing_set:
                    continue
                if _road_id_match(conn_road, main_loop_ids):
                    self._mainRacingRoads.append(conn_road)
                    main_racing_set.add(conn_road)
                    conn_name = getattr(conn_road, 'name', str(conn_road))[:50]
                    conn_len = _road_length(conn_road)
                    print(f"  [INFO] Main racing (junction link): {conn_name} ({conn_len:.1f}m)")
        else:
            # Auto-select main-loop link per junction: prefer smooth main–main link that flows naturally with the pit (diverges at junction), then longer
            for junc in intersections:
                main_roads_here = [r for r in junc.roads if r in main_racing_set]
                if len(main_roads_here) < 2:
                    continue
                conn_roads_here = [
                    c for c in connecting_roads
                    if c not in main_racing_set and _conn_belongs_to_junction(c, junc, intersections)
                ]
                if not conn_roads_here:
                    continue
                pit_conn_here = _pit_conn_at_junction(junc)
                # Only consider full ramps (avoid lane-merge stubs); 25m threshold
                MIN_MAIN_LOOP_LINK_LENGTH = 25.0
                candidates = []
                for conn in conn_roads_here:
                    if self.pitLaneRoad is not None and _conn_connects_to_road(conn, self.pitLaneRoad):
                        continue
                    if _road_length(conn) < MIN_MAIN_LOOP_LINK_LENGTH:
                        continue
                    score = _smoothness_conn_to_mains(conn, main_roads_here)
                    if score is not None:
                        div = _divergence_angle_with_pit(conn, pit_conn_here) if pit_conn_here else 0.0
                        length = _road_length(conn)
                        # Combined: smoothness + penalty for low divergence (so centerline flows naturally with pit)
                        DIVERGENCE_WEIGHT = 0.2
                        div_penalty = DIVERGENCE_WEIGHT * (math.pi - div) if pit_conn_here else 0.0
                        combined = score + div_penalty
                        candidates.append((combined, -length, conn))
                if not candidates:
                    continue
                candidates.sort(key=lambda x: (x[0], x[1]))
                best_conn = candidates[0][2]
                self._mainRacingRoads.append(best_conn)
                main_racing_set.add(best_conn)
                conn_name = getattr(best_conn, 'name', str(best_conn))[:50]
                conn_len = _road_length(best_conn)
                print(f"  [INFO] Main racing (junction link, smooth): {conn_name} ({conn_len:.1f}m)")

        # Step 3: Create union region for mainRacingRoad
        if self._mainRacingRoads:
            from scenic.core.regions import UnionRegion
            # Combine all main racing roads into one region
            road_regions = []
            for road in self._mainRacingRoads:
                # Each road is a region
                road_regions.append(road)
            
            if len(road_regions) == 1:
                self.mainRacingRoad = road_regions[0]
            else:
                # Create union of all racing roads
                self.mainRacingRoad = UnionRegion(*road_regions)
            
            n_junction_links = len(self._mainRacingRoads) - n_main
            print(f"\n  [OK] Main racing road: Union of {len(self._mainRacingRoads)} road(s)" + (
                f" ({n_junction_links} junction link(s))" if n_junction_links else ""
            ))

        # Summary
        if self._pitRoads and self.mainRacingRoad:
            print(f"  [OK] Two mutually exclusive segments defined:")
            print(f"       - Pit lane: {len(self._pitRoads)} road(s)")
            print(f"       - Main racing: {len(self._mainRacingRoads)} road(s)")
    
    def _isPitLane(self, lane: Lane) -> bool:
        """Determine if a lane belongs to the pit lane road."""
        # Check if this lane's parent road is the pit lane road
        if self.pitLaneRoad and hasattr(lane, 'road'):
            return lane.road == self.pitLaneRoad
        return False
    
    def generateStartingGrid(
        self, 
        numPositions: int = 20,
        spacing: float = 8.0,
        offset: float = 0.0
    ) -> List:
        """Generate starting grid positions.
        
        Args:
            numPositions: Number of grid positions to generate
            spacing: Distance between grid positions (meters)
            offset: Distance from start/finish line (meters)
            
        Returns:
            List of lane regions for the starting grid (Scenic will sample positions from these)
        """
        if self.startFinishLine is None:
            # Use the beginning of the longest road as start/finish
            longest_road = max(
                self.network.roads,
                key=lambda r: sum(lane.centerline.length for lane in r.lanes)
            )
            self.startFinishLine = longest_road.lanes[0].centerline.start
        
        # Generate grid positions along the main straight
        # For now, return the main lane region and let Scenic sample positions from it
        # This ensures cars are always placed within valid lane boundaries
        positions = []
        main_lane = self._getMainRacingLane()
        
        if main_lane:
            # Return the lane region for each grid position
            # Scenic will sample actual positions from this region
            for i in range(numPositions):
                positions.append(main_lane)
        
        self.startingGrid = positions
        return positions
    
    def _getMainRacingLane(self) -> Optional[Lane]:
        """Get the main racing lane (typically the widest or most central lane)."""
        # Find the longest lane that's not a pit lane
        main_lane = None
        max_length = 0.0
        
        for road in self.network.roads:
            for lane in road.lanes:
                if not self._isPitLane(lane):
                    if lane.centerline.length > max_length:
                        max_length = lane.centerline.length
                        main_lane = lane
        
        return main_lane
    
    def distanceAlongTrack(self, position: Vector) -> Optional[float]:
        """Calculate distance along the track from start/finish line.
        
        Args:
            position: Position on track
            
        Returns:
            Distance in meters from start/finish line, or None if not on track
        """
        # Project position onto main racing lane
        main_lane = self._getMainRacingLane()
        if main_lane is None:
            return None
        
        # Find closest point on centerline
        centerline = main_lane.centerline
        # This would need the actual implementation of finding distance along a polyline
        # For now, return a placeholder
        return 0.0  # TODO: Implement proper distance calculation
    
    def getSectorAt(self, position: Vector) -> Optional[Sector]:
        """Get the sector containing the given position."""
        distance = self.distanceAlongTrack(position)
        if distance is None:
            return None
        
        for sector in self.sectors:
            if sector.startDistance <= distance < sector.endDistance:
                return sector
        
        return None
    
    def isOnPitLane(self, position: Vector) -> bool:
        """Check if a position is on the pit lane."""
        if self.pitLane is None:
            return False
        return position in self.pitLane.region
    
    def enforceTrackDirection(self, heading: float, position: Vector) -> bool:
        """Check if a heading at a position matches the track direction.
        
        Args:
            heading: Heading in radians
            position: Position on track
            
        Returns:
            True if heading matches track direction, False otherwise
        """
        # Get expected heading from road direction
        expected_heading = self.network.roadDirection[position]
        
        # Compare headings (allow some tolerance)
        heading_diff = abs(heading - expected_heading)
        if heading_diff > math.pi:
            heading_diff = 2 * math.pi - heading_diff
        
        # If going the wrong way, reject
        tolerance = math.pi / 4  # 45 degrees
        if heading_diff > tolerance:
            if self.direction == 'clockwise':
                raise RejectionException(
                    "Vehicle heading opposite to clockwise track direction"
                )
            else:
                raise RejectionException(
                    "Vehicle heading opposite to counterclockwise track direction"
                )
        
        return True


def createRacingTrack(
    mapFile: str,
    direction: str = 'counterclockwise',
    pitLaneRoadId: Optional[str] = None,
    pitLaneRoadName: Optional[str] = None,
    mainLineRoadId: Optional[str] = None,
    main_loop_connecting_road_ids: Optional[Tuple[Union[int, str], ...]] = None,
    pit_connecting_road_ids: Optional[Tuple[Union[int, str], ...]] = None,
    **map_options
) -> RacingTrack:
    """Create a RacingTrack from a map file.

    Args:
        mapFile: Path to OpenDRIVE (.xodr) file
        direction: Track direction ('clockwise' or 'counterclockwise')
        pitLaneRoadId: OpenDRIVE road ID for pit lane (optional, e.g., "1545702203")
        pitLaneRoadName: Pattern to match pit lane name (optional, e.g., "Pit Lane", "pit")
        mainLineRoadId: OpenDRIVE road ID for main racing line (optional, e.g., "2117817291")
        main_loop_connecting_road_ids: OpenDRIVE road IDs of junction links for outer loop (e.g. (24, 34))
        pit_connecting_road_ids: OpenDRIVE road IDs of junction links to pit (e.g. (25, 30))
        **map_options: Additional options passed to Network.fromFile()

    Returns:
        RacingTrack object with identified segments

    Example::

        # With explicit junction assignment (outer loop vs pit at two junctions)
        track = createRacingTrack(
            'laguna_seca.xodr',
            direction='counterclockwise',
            main_loop_connecting_road_ids=(24, 34),
            pit_connecting_road_ids=(25, 30),
        )
    """
    network = Network.fromFile(mapFile, **map_options)
    track = RacingTrack(
        network,
        direction=direction,
        pitLaneRoadId=pitLaneRoadId,
        pitLaneRoadName=pitLaneRoadName,
        mainLineRoadId=mainLineRoadId,
        main_loop_connecting_road_ids=main_loop_connecting_road_ids,
        pit_connecting_road_ids=pit_connecting_road_ids,
    )
    return track

